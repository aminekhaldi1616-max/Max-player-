import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const MaxPlayApp());

const blue = Color(0xFF258BFF);
const bg = Color(0xFF080D18);
const panel = Color(0xFF111A2B);

class TvChannel {
  final String id, name, category, country, language, description;
  final String logoUrl, streamUrl, sourceUrl, rightsNote;
  final bool enabled;

  const TvChannel({
    required this.id, required this.name, required this.category,
    required this.country, required this.language, required this.description,
    required this.logoUrl, required this.streamUrl, required this.sourceUrl,
    required this.rightsNote, required this.enabled,
  });

  factory TvChannel.fromJson(Map<String, dynamic> json) => TvChannel(
    id: json['id'] ?? '',
    name: json['name'] ?? '',
    category: json['category'] ?? 'أخرى',
    country: json['country'] ?? '',
    language: json['language'] ?? '',
    description: json['description'] ?? '',
    logoUrl: json['logoUrl'] ?? '',
    streamUrl: json['streamUrl'] ?? '',
    sourceUrl: json['sourceUrl'] ?? '',
    rightsNote: json['rightsNote'] ?? '',
    enabled: json['enabled'] == true,
  );
}

class ChannelRepository {
  static Future<List<TvChannel>> load() async {
    final raw = await rootBundle.loadString('assets/channels.json');
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
      .map((item) => TvChannel.fromJson(item as Map<String, dynamic>))
      .toList();
  }
}

class MaxPlayApp extends StatelessWidget {
  const MaxPlayApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Max Play',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<TvChannel>> channelFuture;
  String selected = 'الكل';
  String search = '';
  int tab = 0;
  Set<String> favorites = {};

  @override
  void initState() {
    super.initState();
    channelFuture = ChannelRepository.load();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => favorites = (prefs.getStringList('favorites') ?? []).toSet());
  }

  Future<void> _toggleFavorite(String id) async {
    setState(() {
      favorites.contains(id) ? favorites.remove(id) : favorites.add(id);
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', favorites.toList());
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.play_circle_fill, color: blue, size: 30),
          SizedBox(width: 8),
          Text('MAX PLAY', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        ]),
        actions: [
          IconButton(
            tooltip: tab == 0 ? 'المفضلة' : 'الرئيسية',
            onPressed: () => setState(() => tab = 1 - tab),
            icon: Icon(tab == 0 ? Icons.favorite_border : Icons.home_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: FutureBuilder<List<TvChannel>>(
          future: channelFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError || !snapshot.hasData) {
              return const Center(child: Text('تعذر تحميل قائمة القنوات. تحقق من ملف البيانات.'));
            }
            final all = snapshot.data!;
            Iterable<TvChannel> items = all.where((c) => c.enabled);
            if (tab == 1) items = items.where((c) => favorites.contains(c.id));
            if (selected != 'الكل') items = items.where((c) => c.category == selected);
            if (search.trim().isNotEmpty) {
              items = items.where((c) => c.name.toLowerCase().contains(search.toLowerCase()));
            }
            final visible = items.toList();

            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    gradient: const LinearGradient(colors: [Color(0xFF123A70), Color(0xFF101A31)]),
                  ),
                  child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('عالم الترفيه بين يديك', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    SizedBox(height: 6),
                    Text('قنوات مباشرة • رياضة • محتوى متنوع', style: TextStyle(color: Colors.white70)),
                    SizedBox(height: 14),
                    Row(children: [
                      Icon(Icons.live_tv, color: Colors.white),
                      SizedBox(width: 8),
                      Text('MAX PLAY', style: TextStyle(fontWeight: FontWeight.bold)),
                      Spacer(),
                      Text('نسخة تطوير', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ]),
                  ]),
                ),
                const SizedBox(height: 16),
                TextField(
                  onChanged: (v) => setState(() => search = v),
                  decoration: InputDecoration(
                    hintText: 'ابحث عن قناة...',
                    prefixIcon: const Icon(Icons.search),
                    filled: true, fillColor: panel,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 42,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: ['الكل', 'العربية', 'الأجنبية', 'الرياضة'].map((item) {
                      final active = selected == item;
                      return Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: ChoiceChip(
                          label: Text(item), selected: active,
                          onSelected: (_) => setState(() { selected = item; tab = 0; }),
                          selectedColor: blue, backgroundColor: panel,
                          labelStyle: const TextStyle(color: Colors.white),
                          side: BorderSide.none,
                        ),
                      );
                    }).toList(),
                  ),
                ),
                const SizedBox(height: 18),
                Row(children: [
                  Text(tab == 1 ? 'قنواتك المفضلة' : 'القنوات', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  Text('${visible.length} قناة', style: const TextStyle(color: Colors.white54)),
                ]),
                const SizedBox(height: 10),
                if (visible.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
                    child: const Column(children: [
                      Icon(Icons.live_tv, size: 42, color: Colors.white38),
                      SizedBox(height: 10),
                      Text('لا توجد قنوات مفعّلة حالياً', style: TextStyle(color: Colors.white70)),
                      Text('أضف سجلات موثوقة ومصرحاً بها في assets/channels.json ثم فعّلها.',
                        style: TextStyle(color: Colors.white38), textAlign: TextAlign.center),
                    ]),
                  )
                else
                  ...visible.map((channel) => ChannelTile(
                    channel: channel,
                    favorite: favorites.contains(channel.id),
                    onFavorite: () => _toggleFavorite(channel.id),
                  )),
                const SizedBox(height: 18),
                const Text(
                  'تُعرض فقط القنوات التي تم التحقق من مصدرها وترخيص استخدامها. لا تُضف شعاراً أو رابط بث دون إذن.',
                  style: TextStyle(color: Colors.white38, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ],
            );
          },
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel,
        indicatorColor: blue.withOpacity(.25),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
        ],
      ),
    ),
  );
}

class ChannelTile extends StatelessWidget {
  final TvChannel channel;
  final bool favorite;
  final VoidCallback onFavorite;
  const ChannelTile({super.key, required this.channel, required this.favorite, required this.onFavorite});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      leading: ChannelLogo(url: channel.logoUrl),
      title: Text(channel.name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${channel.category} • ${channel.country}', style: const TextStyle(color: Colors.white54)),
      trailing: Wrap(spacing: 0, children: [
        IconButton(
          tooltip: favorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة',
          onPressed: onFavorite,
          icon: Icon(favorite ? Icons.favorite : Icons.favorite_border,
            color: favorite ? Colors.redAccent : Colors.white54),
        ),
        IconButton(
          tooltip: 'مشاهدة',
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(channel: channel))),
          icon: const Icon(Icons.play_circle_fill, color: blue, size: 30),
        ),
      ]),
    ),
  );
}

class ChannelLogo extends StatelessWidget {
  final String url;
  const ChannelLogo({super.key, required this.url});
  @override
  Widget build(BuildContext context) => Container(
    width: 52, height: 52,
    decoration: BoxDecoration(color: blue.withOpacity(.14), borderRadius: BorderRadius.circular(14)),
    clipBehavior: Clip.antiAlias,
    child: url.isEmpty
      ? const Icon(Icons.live_tv, color: blue, size: 28)
      : Image.network(
          url, fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const Icon(Icons.live_tv, color: blue, size: 28),
          loadingBuilder: (context, child, progress) => progress == null
            ? child
            : const Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))),
        ),
  );
}

class PlayerPage extends StatefulWidget {
  final TvChannel channel;
  const PlayerPage({super.key, required this.channel});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  VideoPlayerController? controller;
  String? error;

  @override
  void initState() {
    super.initState();
    final url = widget.channel.streamUrl.trim();
    if (!widget.channel.enabled || url.isEmpty) {
      error = 'لا يوجد رابط بث مرخص ومفعّل لهذه القناة حالياً.';
    } else {
      controller = VideoPlayerController.networkUrl(Uri.parse(url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          controller?.play();
        }).catchError((_) {
          if (mounted) setState(() => error = 'تعذر تشغيل البث. تحقق من الرابط والاتصال وحقوق الوصول.');
        });
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: Text(widget.channel.name)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            AspectRatio(
              aspectRatio: 16/9,
              child: Container(
                decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(18)),
                child: controller?.value.isInitialized == true
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: AspectRatio(aspectRatio: controller!.value.aspectRatio, child: VideoPlayer(controller!)),
                    )
                  : const Center(child: Icon(Icons.live_tv, color: blue, size: 64)),
              ),
            ),
            const SizedBox(height: 18),
            Text(error ?? 'جارٍ تحميل البث...', textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70)),
            if (controller?.value.isInitialized == true)
              IconButton(
                onPressed: () => setState(() {
                  controller!.value.isPlaying ? controller!.pause() : controller!.play();
                }),
                icon: Icon(controller!.value.isPlaying ? Icons.pause_circle : Icons.play_circle, size: 44, color: blue),
              ),
          ]),
        ),
      ),
    ),
  );
}
